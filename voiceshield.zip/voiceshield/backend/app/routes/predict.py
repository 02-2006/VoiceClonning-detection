import uuid
import logging

from fastapi import APIRouter, UploadFile, File, HTTPException

from app.pipeline.preprocess import preprocess, duration_seconds, AudioValidationError
from app.pipeline.ensemble import fuse
from app.models.rawnet2 import rawnet2_service
from app.models.aasist import aasist_service
from app.db import insert_scan, list_scans

router = APIRouter()
logger = logging.getLogger("voiceshield.predict")


@router.post("/predict")
async def predict(file: UploadFile = File(...)):
    raw = await file.read()
    if not raw:
        raise HTTPException(400, "Uploaded file is empty.")

    try:
        waveform, sr = preprocess(raw)
    except AudioValidationError as exc:
        raise HTTPException(400, str(exc)) from exc

    if not rawnet2_service.is_ready() or not aasist_service.is_ready():
        raise HTTPException(
            503,
            "Model checkpoints are not loaded yet, so this endpoint cannot return a real "
            "prediction. See /models for status and README.md for how to supply checkpoints. "
            "(This API intentionally refuses to fabricate a result.)",
        )

    rn_result = rawnet2_service.predict(waveform)
    aa_result = aasist_service.predict(waveform)
    ensemble = fuse(rn_result, aa_result)

    dur = duration_seconds(waveform, sr)
    scan_id = str(uuid.uuid4())
    insert_scan(
        scan_id=scan_id,
        filename=file.filename or "unknown",
        duration_seconds=dur,
        prediction=ensemble.prediction,
        confidence=ensemble.confidence,
        threat_score=ensemble.threat_score,
        risk_level=ensemble.risk_level,
        rawnet2_genuine=rn_result.genuine_prob,
        rawnet2_spoof=rn_result.spoof_prob,
        aasist_genuine=aa_result.genuine_prob,
        aasist_spoof=aa_result.spoof_prob,
    )

    return {
        "scan_id": scan_id,
        "audio_duration_seconds": dur,
        "prediction": ensemble.prediction,
        "confidence": ensemble.confidence,
        "threat_score": ensemble.threat_score,
        "risk_level": ensemble.risk_level,
        "requires_captcha": ensemble.requires_captcha,
        "models": {
            "rawnet2": {
                "genuine_probability": rn_result.genuine_prob,
                "spoof_probability": rn_result.spoof_prob,
                "inference_time_ms": rn_result.inference_time_ms,
            },
            "aasist": {
                "genuine_probability": aa_result.genuine_prob,
                "spoof_probability": aa_result.spoof_prob,
                "embedding_score": aa_result.embedding_score,
                "inference_time_ms": aa_result.inference_time_ms,
            },
        },
    }


@router.get("/history")
async def history(limit: int = 50):
    return {"scans": list_scans(limit)}
