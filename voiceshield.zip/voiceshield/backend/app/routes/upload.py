import os
import uuid

from fastapi import APIRouter, UploadFile, File, HTTPException

router = APIRouter()

UPLOAD_DIR = os.environ.get("UPLOAD_DIR", "uploads")
MAX_FILE_SIZE_MB = 15
ALLOWED_EXTENSIONS = {".wav", ".mp3", ".m4a", ".ogg", ".flac", ".webm"}

os.makedirs(UPLOAD_DIR, exist_ok=True)


@router.post("/upload")
async def upload_audio(file: UploadFile = File(...)):
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, f"Unsupported file type '{ext}'. Allowed: {sorted(ALLOWED_EXTENSIONS)}")

    raw = await file.read()
    size_mb = len(raw) / (1024 * 1024)
    if size_mb > MAX_FILE_SIZE_MB:
        raise HTTPException(400, f"File too large ({size_mb:.1f}MB). Max is {MAX_FILE_SIZE_MB}MB.")
    if len(raw) == 0:
        raise HTTPException(400, "Uploaded file is empty.")

    file_id = str(uuid.uuid4())
    stored_path = os.path.join(UPLOAD_DIR, f"{file_id}{ext}")
    with open(stored_path, "wb") as f:
        f.write(raw)

    return {
        "file_id": file_id,
        "filename": file.filename,
        "size_bytes": len(raw),
        "stored_path": stored_path,
    }
