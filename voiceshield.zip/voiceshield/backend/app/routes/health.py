from fastapi import APIRouter
from app.models.rawnet2 import rawnet2_service
from app.models.aasist import aasist_service

router = APIRouter()


@router.get("/health")
async def health():
    return {
        "status": "ok",
        "rawnet2_loaded": rawnet2_service.is_ready(),
        "aasist_loaded": aasist_service.is_ready(),
    }
