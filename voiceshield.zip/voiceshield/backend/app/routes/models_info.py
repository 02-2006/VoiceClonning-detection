from fastapi import APIRouter
from app.models.rawnet2 import rawnet2_service, CHECKPOINT_PATH as RAWNET2_CKPT
from app.models.aasist import aasist_service, CHECKPOINT_PATH as AASIST_CKPT
from app.pipeline.ensemble import W_RAWNET2, W_AASIST

router = APIRouter()


@router.get("/models")
async def models_info():
    return {
        "rawnet2": {
            "loaded": rawnet2_service.is_ready(),
            "checkpoint_path": RAWNET2_CKPT,
            "device": str(rawnet2_service.device),
        },
        "aasist": {
            "loaded": aasist_service.is_ready(),
            "checkpoint_path": AASIST_CKPT,
            "device": str(aasist_service.device),
        },
        "ensemble_weights": {
            "rawnet2": W_RAWNET2,
            "aasist": W_AASIST,
        },
    }
