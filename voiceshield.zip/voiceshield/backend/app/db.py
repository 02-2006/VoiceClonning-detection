"""
Minimal SQLite persistence for scan history.
Swap the connection string for Postgres (e.g. via SQLAlchemy) when you
outgrow SQLite — schema stays the same.
"""
import os
import sqlite3
import datetime
from contextlib import contextmanager

DB_PATH = os.environ.get("DB_PATH", "voiceshield.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS scans (
    id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    filename TEXT,
    duration_seconds REAL,
    prediction TEXT,
    confidence REAL,
    threat_score REAL,
    risk_level TEXT,
    rawnet2_genuine REAL,
    rawnet2_spoof REAL,
    aasist_genuine REAL,
    aasist_spoof REAL
);
"""


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.execute(SCHEMA)


def insert_scan(scan_id: str, filename: str, duration_seconds: float,
                 prediction: str, confidence: float, threat_score: float, risk_level: str,
                 rawnet2_genuine: float, rawnet2_spoof: float,
                 aasist_genuine: float, aasist_spoof: float):
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO scans
               (id, created_at, filename, duration_seconds, prediction, confidence,
                threat_score, risk_level, rawnet2_genuine, rawnet2_spoof,
                aasist_genuine, aasist_spoof)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (scan_id, datetime.datetime.utcnow().isoformat(), filename, duration_seconds,
             prediction, confidence, threat_score, risk_level,
             rawnet2_genuine, rawnet2_spoof, aasist_genuine, aasist_spoof),
        )


def list_scans(limit: int = 50):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM scans ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


init_db()
