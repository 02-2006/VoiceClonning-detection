"""
VoiceShield AI - Backend entrypoint.

Run locally:
    uvicorn app.main:app --reload --port 8000

Run in Docker:
    see ../Dockerfile
"""
import time
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routes import predict, upload, health, models_info

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("voiceshield")

app = FastAPI(
    title="VoiceShield AI",
    description="Real-time AI voice clone / anti-spoofing detection API",
    version="0.1.0",
)

# NOTE: lock this down to your real frontend origin(s) before going to production,
# e.g. ["https://your-app.netlify.app"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, tags=["health"])
app.include_router(models_info.router, tags=["models"])
app.include_router(upload.router, tags=["upload"])
app.include_router(predict.router, tags=["predict"])


@app.middleware("http")
async def add_process_time_header(request, call_next):
    start = time.time()
    response = await call_next(request)
    response.headers["X-Process-Time-Ms"] = str(round((time.time() - start) * 1000, 2))
    return response


@app.get("/")
async def root():
    return {
        "service": "VoiceShield AI",
        "status": "running",
        "docs": "/docs",
    }
