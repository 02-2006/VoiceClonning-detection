"""
Weighted-fusion ensemble decision engine.

Final spoof score = w_rawnet2 * rawnet2.spoof_prob + w_aasist * aasist.spoof_prob
Weights are configurable via env vars so they can be tuned/calibrated later.
"""
import os
from dataclasses import dataclass, asdict

from app.models.rawnet2 import ModelResult as RawNetResult
from app.models.aasist import ModelResult as AasistResult

W_RAWNET2 = float(os.environ.get("ENSEMBLE_WEIGHT_RAWNET2", "0.5"))
W_AASIST = float(os.environ.get("ENSEMBLE_WEIGHT_AASIST", "0.5"))

CAPTCHA_LOW = 0.40
CAPTCHA_HIGH = 0.70


@dataclass
class EnsembleResult:
    prediction: str          # "REAL" | "FAKE"
    confidence: float        # 0-1
    threat_score: float      # 0-1 (== spoof probability)
    risk_level: str          # "LOW" | "MEDIUM" | "HIGH"
    requires_captcha: bool

    def as_dict(self):
        return asdict(self)


def risk_level_for(spoof_score: float) -> str:
    if spoof_score < 0.35:
        return "LOW"
    if spoof_score < 0.70:
        return "MEDIUM"
    return "HIGH"


def fuse(rawnet2: RawNetResult, aasist: AasistResult) -> EnsembleResult:
    spoof_score = W_RAWNET2 * rawnet2.spoof_prob + W_AASIST * aasist.spoof_prob
    genuine_score = 1 - spoof_score

    prediction = "FAKE" if spoof_score >= 0.5 else "REAL"
    confidence = max(spoof_score, genuine_score)
    requires_captcha = CAPTCHA_LOW < spoof_score < CAPTCHA_HIGH

    return EnsembleResult(
        prediction=prediction,
        confidence=round(confidence, 4),
        threat_score=round(spoof_score, 4),
        risk_level=risk_level_for(spoof_score),
        requires_captcha=requires_captcha,
    )
