"""
Real audio preprocessing pipeline.

Upload/Mic bytes -> WAV -> mono -> 16kHz -> trim silence -> normalize -> tensor

This module does real signal processing (via librosa/soundfile/numpy).
No steps here are faked or simulated.
"""
from __future__ import annotations

import io
import numpy as np
import librosa
import soundfile as sf

TARGET_SR = 16000
MAX_AUDIO_SECONDS = 30  # security: cap max processed length


class AudioValidationError(Exception):
    pass


def load_audio_bytes(raw_bytes: bytes) -> tuple[np.ndarray, int]:
    """Decode arbitrary uploaded audio bytes into a numpy waveform + sample rate."""
    try:
        data, sr = sf.read(io.BytesIO(raw_bytes), dtype="float32", always_2d=False)
    except Exception as exc:
        raise AudioValidationError(f"Could not decode audio file: {exc}") from exc

    if data.size == 0:
        raise AudioValidationError("Uploaded audio is empty.")

    return data, sr


def to_mono(waveform: np.ndarray) -> np.ndarray:
    if waveform.ndim == 1:
        return waveform
    return np.mean(waveform, axis=1)


def resample(waveform: np.ndarray, orig_sr: int, target_sr: int = TARGET_SR) -> np.ndarray:
    if orig_sr == target_sr:
        return waveform
    return librosa.resample(waveform, orig_sr=orig_sr, target_sr=target_sr)


def trim_silence(waveform: np.ndarray, top_db: int = 30) -> np.ndarray:
    trimmed, _ = librosa.effects.trim(waveform, top_db=top_db)
    # guard against trimming everything away on very quiet clips
    return trimmed if trimmed.size > 0 else waveform


def normalize(waveform: np.ndarray) -> np.ndarray:
    peak = np.max(np.abs(waveform)) if waveform.size else 0.0
    if peak == 0:
        return waveform
    return waveform / peak


def enforce_max_length(waveform: np.ndarray, sr: int, max_seconds: int = MAX_AUDIO_SECONDS) -> np.ndarray:
    max_samples = sr * max_seconds
    if waveform.shape[0] > max_samples:
        return waveform[:max_samples]
    return waveform


def preprocess(raw_bytes: bytes) -> tuple[np.ndarray, int]:
    """
    Full pipeline: raw upload bytes -> clean 16kHz mono float32 waveform.
    Returns (waveform, sample_rate).
    """
    waveform, sr = load_audio_bytes(raw_bytes)
    waveform = to_mono(waveform)
    waveform = resample(waveform, sr, TARGET_SR)
    waveform = trim_silence(waveform)
    waveform = normalize(waveform)
    waveform = enforce_max_length(waveform, TARGET_SR)
    return waveform, TARGET_SR


def duration_seconds(waveform: np.ndarray, sr: int = TARGET_SR) -> float:
    return round(len(waveform) / sr, 3)
