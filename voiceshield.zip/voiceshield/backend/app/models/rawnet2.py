"""
RawNet2 anti-spoofing model.

Architecture follows the RawNet2 design used in ASVspoof baselines
(sinc-conv front end + residual blocks + GRU + FC classifier).

IMPORTANT — HONESTY ABOUT MODEL STATE:
This file defines the real architecture and a real forward pass. It does NOT
ship pretrained weights (none are bundled, and none were downloaded — this
environment has no internet access). Without a checkpoint file, `load()`
below will refuse to serve predictions rather than silently returning
untrained-model noise as if it were a real result.

To make this real:
1. Obtain official RawNet2 weights trained on ASVspoof2019 LA
   (e.g. from the ASVspoof baseline repos) or train your own.
2. Place the checkpoint at CHECKPOINT_PATH (env-configurable).
3. Restart the service — /health and /models will report it as loaded.
"""
from __future__ import annotations

import os
import time
import logging
from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger("voiceshield.rawnet2")

CHECKPOINT_PATH = os.environ.get("RAWNET2_CHECKPOINT", "checkpoints/rawnet2.pth")


class SincConv(nn.Module):
    """Simplified SincNet-style first layer used by RawNet2."""

    def __init__(self, out_channels: int = 128, kernel_size: int = 251, sample_rate: int = 16000):
        super().__init__()
        self.out_channels = out_channels
        self.kernel_size = kernel_size if kernel_size % 2 == 1 else kernel_size + 1
        self.sample_rate = sample_rate
        low_hz = torch.linspace(30, sample_rate / 2 - 200, out_channels)
        self.low_hz_ = nn.Parameter(low_hz.view(-1, 1))
        self.band_hz_ = nn.Parameter(torch.full((out_channels, 1), 200.0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        device = x.device
        n = torch.arange(-(self.kernel_size // 2), self.kernel_size // 2 + 1, device=device).float()
        low = torch.clamp(self.low_hz_, 30, self.sample_rate / 2)
        high = torch.clamp(low + torch.abs(self.band_hz_), 60, self.sample_rate / 2)
        filters = []
        for f_low, f_high in zip(low, high):
            band = (torch.sin(2 * np.pi * f_high * n / self.sample_rate) -
                    torch.sin(2 * np.pi * f_low * n / self.sample_rate)) / (np.pi * n + 1e-8)
            band[self.kernel_size // 2] = 2 * (f_high - f_low) / self.sample_rate
            window = torch.hamming_window(self.kernel_size, device=device)
            filters.append(band * window)
        kernel = torch.stack(filters).unsqueeze(1)
        return F.conv1d(x, kernel, stride=1, padding=self.kernel_size // 2)


class ResBlock(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        self.bn1 = nn.BatchNorm1d(channels)
        self.conv1 = nn.Conv1d(channels, channels, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm1d(channels)
        self.conv2 = nn.Conv1d(channels, channels, kernel_size=3, padding=1)
        self.pool = nn.MaxPool1d(3)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        out = self.conv1(F.leaky_relu(self.bn1(x), 0.3))
        out = self.conv2(F.leaky_relu(self.bn2(out), 0.3))
        out = out + residual
        return self.pool(out)


class RawNet2(nn.Module):
    def __init__(self, channels: int = 128, num_res_blocks: int = 4, gru_hidden: int = 1024):
        super().__init__()
        self.sinc = SincConv(out_channels=channels)
        self.bn0 = nn.BatchNorm1d(channels)
        self.res_blocks = nn.Sequential(*[ResBlock(channels) for _ in range(num_res_blocks)])
        self.gru = nn.GRU(input_size=channels, hidden_size=gru_hidden, num_layers=2, batch_first=True)
        self.fc1 = nn.Linear(gru_hidden, 128)
        self.fc2 = nn.Linear(128, 2)  # [genuine, spoof]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, 1, samples)
        out = self.sinc(x)
        out = F.max_pool1d(torch.abs(out), 3)
        out = self.bn0(out)
        out = self.res_blocks(out)
        out = out.transpose(1, 2)  # (batch, time, channels)
        out, _ = self.gru(out)
        out = out[:, -1, :]
        out = F.leaky_relu(self.fc1(out), 0.3)
        logits = self.fc2(out)
        return logits


@dataclass
class ModelResult:
    genuine_prob: float
    spoof_prob: float
    inference_time_ms: float


class RawNet2Service:
    """Loads (if available) and serves the RawNet2 model."""

    def __init__(self, checkpoint_path: str = CHECKPOINT_PATH):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = RawNet2().to(self.device)
        self.loaded = False
        self.checkpoint_path = checkpoint_path
        self._try_load()

    def _try_load(self) -> None:
        if os.path.exists(self.checkpoint_path):
            state = torch.load(self.checkpoint_path, map_location=self.device)
            self.model.load_state_dict(state)
            self.loaded = True
            logger.info("RawNet2 checkpoint loaded from %s", self.checkpoint_path)
        else:
            logger.warning(
                "RawNet2 checkpoint not found at %s — model is UNTRAINED. "
                "Predictions will be refused until a real checkpoint is supplied.",
                self.checkpoint_path,
            )
        self.model.eval()

    def is_ready(self) -> bool:
        return self.loaded

    @torch.no_grad()
    def predict(self, waveform: np.ndarray) -> ModelResult:
        if not self.loaded:
            raise RuntimeError(
                "RawNet2 checkpoint is not loaded. Refusing to fabricate a prediction. "
                "Supply real pretrained weights at RAWNET2_CHECKPOINT."
            )
        start = time.time()
        x = torch.from_numpy(waveform).float().unsqueeze(0).unsqueeze(0).to(self.device)
        logits = self.model(x)
        probs = F.softmax(logits, dim=-1).squeeze(0).cpu().numpy()
        elapsed_ms = (time.time() - start) * 1000
        return ModelResult(
            genuine_prob=float(probs[0]),
            spoof_prob=float(probs[1]),
            inference_time_ms=round(elapsed_ms, 2),
        )


# module-level singleton, imported by routes
rawnet2_service = RawNet2Service()
