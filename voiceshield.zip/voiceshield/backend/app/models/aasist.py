"""
AASIST anti-spoofing model.

This is a simplified but real graph-attention based architecture in the
spirit of AASIST (spectro-temporal graph attention network). Like rawnet2.py,
this does NOT ship pretrained weights.

For a fully faithful reproduction, swap this module's internals for the
official AASIST repo implementation and load their released checkpoint —
architecture fidelity matters for matching published accuracy numbers.

Until a real checkpoint is supplied, this service refuses to predict rather
than returning meaningless numbers dressed up as a result.
"""
from __future__ import annotations

import os
import time
import logging
from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger("voiceshield.aasist")

CHECKPOINT_PATH = os.environ.get("AASIST_CHECKPOINT", "checkpoints/aasist.pth")


class GraphAttentionLayer(nn.Module):
    """Simplified self-attention over frame-level embeddings (stand-in for
    AASIST's heterogeneous spectro-temporal graph attention)."""

    def __init__(self, dim: int, heads: int = 4):
        super().__init__()
        self.attn = nn.MultiheadAttention(embed_dim=dim, num_heads=heads, batch_first=True)
        self.norm = nn.LayerNorm(dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out, _ = self.attn(x, x, x)
        return self.norm(x + out)


class AASIST(nn.Module):
    def __init__(self, embed_dim: int = 128, n_layers: int = 3):
        super().__init__()
        self.frontend = nn.Sequential(
            nn.Conv1d(1, 64, kernel_size=251, stride=10, padding=125),
            nn.BatchNorm1d(64),
            nn.LeakyReLU(0.3),
            nn.Conv1d(64, embed_dim, kernel_size=5, stride=2, padding=2),
            nn.BatchNorm1d(embed_dim),
            nn.LeakyReLU(0.3),
        )
        self.graph_layers = nn.ModuleList([GraphAttentionLayer(embed_dim) for _ in range(n_layers)])
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, 64),
            nn.LeakyReLU(0.3),
            nn.Linear(64, 2),  # [genuine, spoof]
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, 1, samples)
        feats = self.frontend(x)              # (batch, embed_dim, time)
        feats = feats.transpose(1, 2)          # (batch, time, embed_dim)
        for layer in self.graph_layers:
            feats = layer(feats)
        pooled = feats.mean(dim=1)             # global average pooling over time
        return self.classifier(pooled), pooled


@dataclass
class ModelResult:
    genuine_prob: float
    spoof_prob: float
    embedding_score: float
    inference_time_ms: float


class AASISTService:
    def __init__(self, checkpoint_path: str = CHECKPOINT_PATH):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = AASIST().to(self.device)
        self.loaded = False
        self.checkpoint_path = checkpoint_path
        self._try_load()

    def _try_load(self) -> None:
        if os.path.exists(self.checkpoint_path):
            state = torch.load(self.checkpoint_path, map_location=self.device)
            self.model.load_state_dict(state)
            self.loaded = True
            logger.info("AASIST checkpoint loaded from %s", self.checkpoint_path)
        else:
            logger.warning(
                "AASIST checkpoint not found at %s — model is UNTRAINED. "
                "Predictions will be refused until a real checkpoint is supplied.",
                self.checkpoint_path,
            )
        self.model.eval()

    def is_ready(self) -> bool:
        return self.loaded

    @torch.no_grad()
    def predict(self, waveform: np.ndarray) -> ModelResult:
        if not self.loaded:
            raise RuntimeError(
                "AASIST checkpoint is not loaded. Refusing to fabricate a prediction. "
                "Supply real pretrained weights at AASIST_CHECKPOINT."
            )
        start = time.time()
        x = torch.from_numpy(waveform).float().unsqueeze(0).unsqueeze(0).to(self.device)
        logits, pooled = self.model(x)
        probs = F.softmax(logits, dim=-1).squeeze(0).cpu().numpy()
        embedding_score = float(torch.norm(pooled).cpu().item())
        elapsed_ms = (time.time() - start) * 1000
        return ModelResult(
            genuine_prob=float(probs[0]),
            spoof_prob=float(probs[1]),
            embedding_score=embedding_score,
            inference_time_ms=round(elapsed_ms, 2),
        )


aasist_service = AASISTService()
