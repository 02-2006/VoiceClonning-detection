Place real pretrained checkpoints here:
  - rawnet2.pth
  - aasist.pth

The API will refuse to return predictions until real files exist here
(see app/models/rawnet2.py and app/models/aasist.py). This is intentional —
it prevents the API from silently serving untrained-model noise as if it
were a genuine detection result.
