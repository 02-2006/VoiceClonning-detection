const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export interface ModelScore {
  genuine_probability: number;
  spoof_probability: number;
  inference_time_ms: number;
  embedding_score?: number;
}

export interface PredictResponse {
  scan_id: string;
  audio_duration_seconds: number;
  prediction: "REAL" | "FAKE";
  confidence: number;
  threat_score: number;
  risk_level: "LOW" | "MEDIUM" | "HIGH";
  requires_captcha: boolean;
  models: {
    rawnet2: ModelScore;
    aasist: ModelScore;
  };
}

export async function predictAudio(blob: Blob, filename: string): Promise<PredictResponse> {
  const form = new FormData();
  form.append("file", blob, filename);

  const res = await fetch(`${API_URL}/predict`, {
    method: "POST",
    body: form,
  });

  if (!res.ok) {
    const detail = await res.json().catch(() => ({}));
    throw new Error(detail.detail || `Prediction failed (${res.status})`);
  }
  return res.json();
}

export interface ScanHistoryItem {
  id: string;
  created_at: string;
  filename: string;
  duration_seconds: number;
  prediction: string;
  confidence: number;
  threat_score: number;
  risk_level: string;
}

export async function fetchHistory(limit = 50): Promise<ScanHistoryItem[]> {
  const res = await fetch(`${API_URL}/history?limit=${limit}`);
  if (!res.ok) throw new Error("Failed to load history");
  const data = await res.json();
  return data.scans;
}

export async function fetchHealth() {
  const res = await fetch(`${API_URL}/health`);
  return res.json();
}
