/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#f3f6fb",
          600: "#2952cc",
          700: "#1f3fa3",
        },
      },
    },
  },
  plugins: [],
};
