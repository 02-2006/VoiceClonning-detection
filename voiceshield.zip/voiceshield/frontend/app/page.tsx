"use client";

import { useState, useCallback } from "react";
import MicRecorder from "@/components/MicRecorder";
import ResultCard from "@/components/ResultCard";
import { predictAudio, PredictResponse } from "@/lib/api";

export default function DetectionPage() {
  const [result, setResult] = useState<PredictResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const runDetection = useCallback(async (blob: Blob, filename: string) => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await predictAudio(blob, filename);
      setResult(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Detection failed");
    } finally {
      setLoading(false);
    }
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) runDetection(file, file.name);
  };

  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <header className="mb-10 text-center">
        <h1 className="text-3xl font-bold">VoiceShield AI</h1>
        <p className="mt-2 text-slate-500">Detect AI voice cloning attacks in real time</p>
      </header>

      <div className="grid gap-6">
        <MicRecorder onRecordingComplete={(blob) => runDetection(blob, "recording.webm")} />

        <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-sm">
          <label className="cursor-pointer text-brand-600 hover:underline">
            Or upload an audio file
            <input type="file" accept="audio/*" className="hidden" onChange={handleFileUpload} />
          </label>
        </div>

        {loading && (
          <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-slate-500 shadow-sm">
            Running RawNet2 + AASIST inference…
          </div>
        )}

        {error && (
          <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-red-700">{error}</div>
        )}

        {result && <ResultCard result={result} />}
      </div>
    </main>
  );
}
