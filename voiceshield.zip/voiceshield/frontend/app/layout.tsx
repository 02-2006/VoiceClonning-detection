import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "VoiceShield AI",
  description: "Real-time AI voice clone & anti-spoofing detection",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-50 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
