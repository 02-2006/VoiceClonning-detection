"use client";

import { PredictResponse } from "@/lib/api";

const riskColor: Record<string, string> = {
  LOW: "text-green-600 bg-green-50",
  MEDIUM: "text-amber-600 bg-amber-50",
  HIGH: "text-red-600 bg-red-50",
};

export default function ResultCard({ result }: { result: PredictResponse }) {
  const isFake = result.prediction === "FAKE";

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm font-medium uppercase tracking-wide text-slate-500">Detection Result</div>
          <div className={`mt-1 text-3xl font-bold ${isFake ? "text-red-600" : "text-green-600"}`}>
            {isFake ? "FAKE VOICE DETECTED" : "REAL VOICE"}
          </div>
        </div>
        <div className={`rounded-full px-4 py-1.5 text-sm font-semibold ${riskColor[result.risk_level]}`}>
          {result.risk_level} RISK
        </div>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-4">
        <Stat label="Confidence" value={`${(result.confidence * 100).toFixed(1)}%`} />
        <Stat label="Threat Score" value={`${(result.threat_score * 100).toFixed(1)}%`} />
      </div>

      <div className="mt-6 border-t border-slate-100 pt-6">
        <div className="mb-3 text-sm font-medium text-slate-500">Model Breakdown</div>
        <div className="grid grid-cols-2 gap-4">
          <ModelBox
            name="RawNet2"
            genuine={result.models.rawnet2.genuine_probability}
            spoof={result.models.rawnet2.spoof_probability}
            ms={result.models.rawnet2.inference_time_ms}
          />
          <ModelBox
            name="AASIST"
            genuine={result.models.aasist.genuine_probability}
            spoof={result.models.aasist.spoof_probability}
            ms={result.models.aasist.inference_time_ms}
          />
        </div>
      </div>

      {result.requires_captcha && (
        <div className="mt-6 rounded-lg bg-amber-50 p-4 text-sm text-amber-800">
          Confidence is in the uncertain range — a voice CAPTCHA challenge would normally be
          triggered here to confirm liveness.
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-slate-50 p-4">
      <div className="text-xs uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mt-1 text-2xl font-semibold">{value}</div>
    </div>
  );
}

function ModelBox({ name, genuine, spoof, ms }: { name: string; genuine: number; spoof: number; ms: number }) {
  return (
    <div className="rounded-xl border border-slate-200 p-4">
      <div className="font-medium">{name}</div>
      <div className="mt-2 text-sm text-slate-600">Genuine: {(genuine * 100).toFixed(1)}%</div>
      <div className="text-sm text-slate-600">Spoof: {(spoof * 100).toFixed(1)}%</div>
      <div className="mt-1 text-xs text-slate-400">{ms}ms</div>
    </div>
  );
}
