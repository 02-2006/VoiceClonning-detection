"use client";

import { useRef, useState, useCallback } from "react";

type Status = "idle" | "recording" | "recorded";

interface Props {
  onRecordingComplete: (blob: Blob) => void;
}

export default function MicRecorder({ onRecordingComplete }: Props) {
  const [status, setStatus] = useState<Status>("idle");
  const [seconds, setSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startRecording = useCallback(async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    chunksRef.current = [];

    recorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunksRef.current.push(e.data);
    };
    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: "audio/webm" });
      onRecordingComplete(blob);
      stream.getTracks().forEach((t) => t.stop());
      if (timerRef.current) clearInterval(timerRef.current);
    };

    recorder.start(250); // emit chunks every 250ms — ready for future streaming use
    mediaRecorderRef.current = recorder;
    setStatus("recording");
    setSeconds(0);
    timerRef.current = setInterval(() => setSeconds((s) => s + 1), 1000);
  }, [onRecordingComplete]);

  const stopRecording = useCallback(() => {
    mediaRecorderRef.current?.stop();
    setStatus("recorded");
  }, []);

  return (
    <div className="flex flex-col items-center gap-4 rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
      <div className="text-sm font-medium uppercase tracking-wide text-slate-500">
        Microphone Status: {status === "idle" ? "Ready" : status === "recording" ? "Recording" : "Completed"}
      </div>

      <div
        className={`flex h-24 w-24 items-center justify-center rounded-full transition ${
          status === "recording" ? "animate-pulse bg-red-100" : "bg-brand-50"
        }`}
      >
        <div className={`h-4 w-4 rounded-full ${status === "recording" ? "bg-red-500" : "bg-brand-600"}`} />
      </div>

      {status === "recording" && <div className="text-2xl font-semibold tabular-nums">{seconds}s</div>}

      {status !== "recording" ? (
        <button
          onClick={startRecording}
          className="rounded-lg bg-brand-600 px-6 py-2.5 font-medium text-white hover:bg-brand-700"
        >
          Start Recording
        </button>
      ) : (
        <button
          onClick={stopRecording}
          className="rounded-lg bg-red-600 px-6 py-2.5 font-medium text-white hover:bg-red-700"
        >
          Stop Recording
        </button>
      )}
    </div>
  );
}
